using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DesObj : MonoBehaviour
{
    public string name;
    public int levelId;

    public void InitDes(string _name)
    {
        name = _name;
    }
}
